import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart'as http;
import 'Pagination.dart';

class Test extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Testt();
  }
}

class Testt extends State<Test>
    with TickerProviderStateMixin {
  List<Data> userList = [], pagingList = [];
  ScrollController _sc = new ScrollController();
  var pageIndex = 1, maxCount = 0;

  @override
  void initState() {
    initPrefs();
    super.initState();
  }

  void initPrefs() async {
    _sc.addListener(() {
      if (_sc.position.pixels == _sc.position.maxScrollExtent) {
        if (pageIndex <= maxCount) {
          _userListApi();
        }
      }
    });
    Future.delayed(Duration(milliseconds: 1), () {
      pagingList.clear();
      pageIndex = 1;
      _userListApi();
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(

        child: pagingList.length > 0
            ? ListView.builder(
            primary: false,
            controller: _sc,
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            physics: BouncingScrollPhysics(),
            itemCount: pagingList.length, // the length
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.only(left: 10, right: 10, bottom: 10),
                decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(25.0),
                    border: Border.all(width: 0.1)),
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.height * 0.02,
                    right: MediaQuery.of(context).size.height * 0.02,
                    top: MediaQuery.of(context).size.height * 0.01,
                    bottom: MediaQuery.of(context).size.height * 0.01),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(100.0),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: CircleAvatar(
                        radius: 45,
                        backgroundColor: Colors.white,
                        child: CircleAvatar(
                            radius: 43,
                            backgroundColor: Colors.grey[300],
                            backgroundImage:
                            NetworkImage(pagingList[index].avatar)),
                      ),
                    ),
                    Container(
                      child: Text(
                          pagingList[index].firstName +
                              " " +
                              pagingList[index].lastName,
                          softWrap: true,
                          overflow: TextOverflow.clip,
                          style: TextStyle(

                              fontWeight: FontWeight.bold)),
                    ),
                    Container(
                      child: Text(pagingList[index].email + " ",
                          softWrap: true,
                          overflow: TextOverflow.clip,
                          style: TextStyle(

                          )),
                    ),
                  ],
                ),
              );
            })
            : Center(
        ),
      ),
    );
  }

  Future<dynamic> _userListApi() async {

    var url = "https://reqres.in/api/users?pages=2";
    try {
      final http.Response response = await http.get(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      print(url + " req:");
      return _returnResponse(response);
    } on SocketException catch (_) {

      return;
    } catch (e) {

    }
  }

  dynamic _returnResponse(http.Response response) async {
    print(" res:" + response.body.toString());

    var responseJson = Pagination.fromJson(jsonDecode(response.body));

    switch (response.statusCode) {
      case 200:
        setState(() {
          userList = responseJson.data;
          pagingList.addAll(userList);
          maxCount = responseJson.totalPages;
          print("total app " + maxCount.toString());
          pageIndex++;
        });

        return responseJson;

    }
  }
}
